#### 常用工具

| 名称              | 用途                                    | 下载地址                                                     |
| ----------------- | --------------------------------------- | ------------------------------------------------------------ |
| `wxappUnpacker`   | 小程序源代码获取工具                    | https://github.com/Angels-Ray/wxappUnpacker                  |
| `wxapkgconvertor` | 小程序源代码获取工具                    | https://github.com/Angels-Ray/wxapkg-convertor               |
| `UnpackMiniApp`   | 小程序解密(相当于`wxappUnpacker`的旧版) | https://github.com/Angels-Ray/UnpackMiniApp                  |
| 微信开发者工具    | 调试获取的小程序代码                    | https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html |
| `BurpSuite`       | 抓包分析测试                            | https://portswigger.net/burp                                 |
| `proxifier`       | 流量代理                                | https://www.proxifier.com/                                   |
